package com.clinica.programacion3.clinica_progra3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaProgra3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
