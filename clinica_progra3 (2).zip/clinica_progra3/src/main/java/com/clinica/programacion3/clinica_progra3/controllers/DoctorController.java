package com.clinica.programacion3.clinica_progra3.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.clinica.programacion3.clinica_progra3.entidades.Doctores;
import com.clinica.programacion3.clinica_progra3.services.DoctorServicio;

@RestController
@RequestMapping("/api")
public class DoctorController {

    @Autowired
    private DoctorServicio servicioDoctor;

    @GetMapping("/listarDoctores")
    public ResponseEntity<List<Doctores>> consultarDoctores() {
        List<Doctores> doctores = servicioDoctor.consultarDoctores();
        if (!doctores.isEmpty()) {
            return new ResponseEntity<>(doctores, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}