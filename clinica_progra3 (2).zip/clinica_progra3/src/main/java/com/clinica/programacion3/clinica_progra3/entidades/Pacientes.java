package com.clinica.programacion3.clinica_progra3.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table (name = "pacientes")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Pacientes {


    @Id
    @Column (name = "codigo_paciente")
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long codigo_paciente;

    @Column (name = "nombre_paciente")
    private String nombre_paciente;

    @Column (name = "dni")
    private String dni;

    @Column (name = "edad")
    private Integer edad;

    @Column (name = "direccion")
    private String direccion;

    @Column (name = "telefono")
    private String telefono;

    @Column (name = "correo_electronico")
    private String correo_electronico;

    @Column (name = "sexo")
    private String sexo;

    @Column (name = "telefono_emergencia")
    private String telefono_emergencia;

    @Column (name = "contacto_emergencia")
    private String contacto_emergencia;
}
