package com.clinica.programacion3.clinica_progra3.repositorio;


import org.springframework.data.repository.CrudRepository;

import com.clinica.programacion3.clinica_progra3.entidades.Doctores;

public interface DoctorRepositorio extends CrudRepository<Doctores, Long> {
}