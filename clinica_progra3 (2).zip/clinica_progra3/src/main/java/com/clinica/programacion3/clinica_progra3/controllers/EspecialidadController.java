package com.clinica.programacion3.clinica_progra3.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.clinica.programacion3.clinica_progra3.dto.EspecialidadDto;
import com.clinica.programacion3.clinica_progra3.entidades.Especialidades;
import com.clinica.programacion3.clinica_progra3.services.EspecialidadServicio;


@RestController
@RequestMapping ("/api")

public class EspecialidadController {

    @Autowired
    private EspecialidadServicio servicioEspecialidad;

    @GetMapping ("/listarEspecialidades")
        public ResponseEntity<List<Especialidades>> consultarEspecialidades() {
        List<Especialidades> especialidades = servicioEspecialidad.consultarEspecialidad();
        if (!especialidades.isEmpty()) {
            return new ResponseEntity<>(especialidades, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/borrarEspecialidad/{id}")
    public ResponseEntity<String> borrarEspecialidad(@PathVariable("id") Long id) {
        boolean borrado = servicioEspecialidad.borrarEspecialidad(id);
        if (borrado) {
            return new ResponseEntity<>("Especialidad eliminada correctamente", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se encontró la especialidad con el ID proporcionado", HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/registrarEspecialidad")
public ResponseEntity<Especialidades> registrarEspecialidades(@RequestBody EspecialidadDto especialidadJson){

    Especialidades especialidad = new Especialidades();

    especialidad.setNombre(especialidadJson.getNombre());
    especialidad.setDescripcion(especialidadJson.getDescripcion());
    especialidad.setEstado(false);

    Especialidades especialidadRegistrado = servicioEspecialidad.registrarEspecialidades(especialidad);

    return ResponseEntity.status(HttpStatus.CREATED).body(especialidadRegistrado);
}

@PatchMapping("/actualizarEspecialidad/{id}")
    public ResponseEntity<String> actualizarEspecialidad(@PathVariable("id") Long id, @RequestBody Map<String, Object> camposActualizados) {
        boolean actualizado = servicioEspecialidad.actualizarEspecialidad(id, camposActualizados);
        if (actualizado) {
            return new ResponseEntity<>("Especialidad actualizada correctamente", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se encontró la especialidad con el ID proporcionado", HttpStatus.NOT_FOUND);
        }
    }


}