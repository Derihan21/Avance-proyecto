package com.clinica.programacion3.clinica_progra3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaProgra3Application {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaProgra3Application.class, args);
	}

}
