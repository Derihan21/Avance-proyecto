package com.clinica.programacion3.clinica_progra3.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.clinica.programacion3.clinica_progra3.dto.PacienteDto;
import com.clinica.programacion3.clinica_progra3.entidades.Pacientes;
import com.clinica.programacion3.clinica_progra3.services.PacienteServicio;

@RestController
@RequestMapping ("/api")
public class PacienteController {

    @Autowired
    private PacienteServicio servicioPaciente;


    @GetMapping("/listarPacientes")
    public ResponseEntity<List<Pacientes>> consultarPacientes() {
        List<Pacientes> pacientes = servicioPaciente.consultarPacientes();
        if (!pacientes.isEmpty()) {
            return new ResponseEntity<>(pacientes, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

@DeleteMapping("/borrarPaciente/{id}")
    public ResponseEntity<String> borrarPaciente(@PathVariable("id") Long id) {
        boolean borrado = servicioPaciente.borrarPaciente(id);
        if (borrado) {
            return new ResponseEntity<>("Paciente eliminado correctamente", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se encontró el paciente con el ID proporcionado", HttpStatus.NOT_FOUND);
        }
    }


  @PostMapping("/registrarPaciente")
public ResponseEntity<Pacientes> registrarPacientes(@RequestBody PacienteDto pacienteJson){

    Pacientes paciente = new Pacientes();

    paciente.setNombre_paciente(pacienteJson.getNombre_paciente());
    paciente.setDni(pacienteJson.getDni());
    paciente.setEdad(pacienteJson.getEdad());
    paciente.setDireccion(pacienteJson.getDireccion());
    paciente.setTelefono(pacienteJson.getTelefono());
    paciente.setCorreo_electronico(pacienteJson.getCorreo_electronico());
    paciente.setSexo(pacienteJson.getSexo());
    paciente.setTelefono_emergencia(pacienteJson.getTelefono_emergencia());
    paciente.setContacto_emergencia(pacienteJson.getContacto_emergencia());

    Pacientes pacienteRegistrado = servicioPaciente.registrarPacientes(paciente);

    return ResponseEntity.status(HttpStatus.CREATED).body(pacienteRegistrado);
}

 @PatchMapping("/actualizarPaciente/{id}")
    public ResponseEntity<String> actualizarPaciente(@PathVariable("id") Long id, @RequestBody Map<String, Object> camposActualizados) {
        boolean actualizado = servicioPaciente.actualizarPaciente(id, camposActualizados);
        if (actualizado) {
            return new ResponseEntity<>("Paciente actualizado correctamente", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se encontró el paciente con el ID proporcionado", HttpStatus.NOT_FOUND);
        }
    }
}
