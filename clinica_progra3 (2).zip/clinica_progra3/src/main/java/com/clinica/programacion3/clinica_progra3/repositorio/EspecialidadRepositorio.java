package com.clinica.programacion3.clinica_progra3.repositorio;

import org.springframework.data.repository.CrudRepository;

import com.clinica.programacion3.clinica_progra3.entidades.Especialidades;

public interface EspecialidadRepositorio extends CrudRepository < Especialidades,Long> {

}
