package com.clinica.programacion3.clinica_progra3.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clinica.programacion3.clinica_progra3.entidades.Doctores;
import com.clinica.programacion3.clinica_progra3.repositorio.DoctorRepositorio;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorServicio {

    @Autowired
    private DoctorRepositorio doctorRepositorio;

    public List<Doctores> consultarDoctores() {
        return (List<Doctores>) doctorRepositorio.findAll();
    }

    public Doctores registrarDoctor(Doctores doctor) {
        return doctorRepositorio.save(doctor);
    }

    public boolean borrarDoctor(Long codigoDoctor) {
        if (doctorRepositorio.existsById(codigoDoctor)) {
            doctorRepositorio.deleteById(codigoDoctor);
            return true;
        } else {
            return false;
        }
    }

    public Optional<Doctores> obtenerDoctorPorId(Long codigoDoctor) {
        return doctorRepositorio.findById(codigoDoctor);
    }

    public Doctores actualizarDoctor(Doctores doctor) {
        return doctorRepositorio.save(doctor);
    }
}