package com.clinica.programacion3.clinica_progra3.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DoctorDto {
    private String nombre;
    private String noColegiado;
    private Boolean estado;
    private String telefono;
    private String jornada;
    private Long codigoEspecialidad;
}