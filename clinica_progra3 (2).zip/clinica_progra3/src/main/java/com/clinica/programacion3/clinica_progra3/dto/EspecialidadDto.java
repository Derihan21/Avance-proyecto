package com.clinica.programacion3.clinica_progra3.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class EspecialidadDto {

    private String nombre;
    private String descripcion;
    private boolean estado;
}
