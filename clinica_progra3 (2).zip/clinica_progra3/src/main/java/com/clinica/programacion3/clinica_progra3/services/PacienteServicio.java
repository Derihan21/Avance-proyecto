package com.clinica.programacion3.clinica_progra3.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clinica.programacion3.clinica_progra3.entidades.Pacientes;
import com.clinica.programacion3.clinica_progra3.repositorio.PacienteRepositorio;

@Service
public class PacienteServicio {

    @Autowired
    private PacienteRepositorio pacienteRepositorio;


 public List <Pacientes> consultarPacientes(){
    return (List<Pacientes>) pacienteRepositorio.findAll();   

 }
    @SuppressWarnings("null")
    public Pacientes registrarPacientes(Pacientes paciente){
        return pacienteRepositorio.save(paciente);

 }   

 public boolean borrarPaciente(Long id) {
   if (pacienteRepositorio.existsById(id)) {
       pacienteRepositorio.deleteById(id);
       return true;
   } else {
       return false;
   }

}

public boolean actualizarPaciente(Long id, Map<String, Object> camposActualizados) {
    Optional<Pacientes> pacienteOptional = pacienteRepositorio.findById(id);
    if (pacienteOptional.isPresent()) {
        Pacientes paciente = pacienteOptional.get();
        camposActualizados.forEach((campo, valor) -> {
            switch (campo) {
                case "nombre_paciente":
                    paciente.setNombre_paciente((String) valor);
                    break;
                case "dni":
                    paciente.setDni((String) valor);
                    break;
                case "edad":
                    paciente.setEdad((Integer) valor);
                    break;
                case "direccion":
                    paciente.setDireccion((String) valor);
                    break;
                case "telefono":
                    paciente.setTelefono((String) valor);
                    break;
                case "Correo_electronico":
                    paciente.setCorreo_electronico((String) valor);
                    break;
                case "sexo":
                    paciente.setSexo((String) valor);
                    break;
                case "Telefono_emergencia":
                    paciente.setTelefono_emergencia((String) valor);
                    break;
                case "Contacto_emergencia":
                    paciente.setContacto_emergencia((String) valor);
                    break;
                default:
                   
                    break;
            }
        });
        pacienteRepositorio.save(paciente);
        return true;
    } else {
        return false;
    }
}


}
