package com.clinica.programacion3.clinica_progra3.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.clinica.programacion3.clinica_progra3.entidades.Especialidades;
import com.clinica.programacion3.clinica_progra3.repositorio.EspecialidadRepositorio;

@Service
public class EspecialidadServicio {

    @Autowired
    private EspecialidadRepositorio especialidadRepositorio;
    public List <Especialidades> consultarEspecialidad(){
        return (List<Especialidades>) especialidadRepositorio.findAll();
    }
    @SuppressWarnings("null")
    public Especialidades registrarEspecialidades(Especialidades especialidad){
        return especialidadRepositorio.save(especialidad);
 } 

 public boolean borrarEspecialidad(Long id) {
    if (especialidadRepositorio.existsById(id)) {
        especialidadRepositorio.deleteById(id);
        return true;
    } else {
        return false;
    }
 }

 public boolean actualizarEspecialidad(Long id, Map<String, Object> camposActualizados) {
    Optional<Especialidades> especialidadOptional = especialidadRepositorio.findById(id);
    if (especialidadOptional.isPresent()) {
        Especialidades especialidad = especialidadOptional.get();
        camposActualizados.forEach((campo, valor) -> {
            switch (campo) {
                case "nombre":
                    especialidad.setNombre((String) valor);
                    break;
                case "descripcion":
                    especialidad.setDescripcion((String) valor);
                    break;
                case "estado":
                    especialidad.setEstado((Boolean) valor);
                    break;
                default:
                    // Ignorar campos desconocidos
                    break;
            }
        });
        especialidadRepositorio.save(especialidad);
        return true;
    } else {
        return false;
    }
}


}