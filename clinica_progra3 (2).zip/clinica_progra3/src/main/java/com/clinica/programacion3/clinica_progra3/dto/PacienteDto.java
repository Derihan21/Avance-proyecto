package com.clinica.programacion3.clinica_progra3.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class PacienteDto {

private String nombre_paciente;
private String dni;
private Integer edad;
private String direccion;
private String telefono;
private String correo_electronico;
private String sexo;
private String telefono_emergencia;
private String contacto_emergencia;
}
