package com.clinica.programacion3.clinica_progra3.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Doctores {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_doctor")
    private Long codigoDoctor;
    
    private String nombre;
    @Column(name = "no_colegiado")
    private String noColegiado;
    private Boolean estado;
    private String telefono;
    private String jornada;

    @ManyToOne
    @JoinColumn(name = "codigo_especialidad")
    private Especialidades codigo_especialidad;
}