package com.clinica.programacion3.clinica_progra3.repositorio;

import org.springframework.data.repository.CrudRepository;

import com.clinica.programacion3.clinica_progra3.entidades.Pacientes;

public interface PacienteRepositorio extends CrudRepository<Pacientes,Long> {

}
